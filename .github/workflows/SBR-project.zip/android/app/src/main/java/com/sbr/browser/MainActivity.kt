package com.sbr.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView

// ---------------------------------------------------------------- Renkler
private val C_BG = Color.parseColor("#0f1117")
private val C_BAR = Color.parseColor("#171a23")
private val C_FIELD = Color.parseColor("#232836")
private val C_ACCENT = Color.parseColor("#6c8cff")
private val C_TEXT = Color.parseColor("#e6e8ef")
private val C_DIM = Color.parseColor("#8b90a0")

// ---------------------------------------------------------------- Veri
class Tab(
    val id: Int,
    val session: GeckoSession,
    var title: String,
    var url: String,
    var canBack: Boolean = false,
    var canFwd: Boolean = false,
    val isPrivate: Boolean = false,
    var loading: Boolean = false
)

data class GuardResult(val score: Int, val reasons: List<String>) {
    val icon: String get() = when {
        score == 0 -> "🔒"
        score <= 2 -> "⚠️"
        else -> "⛔"
    }
    val label: String get() = when {
        score == 0 -> "Güvenli görünüyor"
        score <= 2 -> "Dikkat"
        else -> "Riskli olabilir"
    }
}

// ---------------------------------------------------------------- S.BR Guard
object Guard {
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
    private val badTlds = setOf("zip", "mov", "tk", "ml", "ga", "cf", "gq", "top", "xyz")
    private val words = listOf("login", "verify", "secure", "update", "account")

    fun check(url: String): GuardResult {
        if (url.isEmpty() || url.startsWith("about:") || url.startsWith("data:")) {
            return GuardResult(0, listOf("Başlangıç / boş sayfa."))
        }
        var score = 0
        val reasons = ArrayList<String>()
        val lower = url.lowercase()
        val host = (try { Uri.parse(url).host } catch (e: Exception) { null } ?: "").lowercase()

        if (lower.startsWith("http://")) { score += 2; reasons.add("Adres şifrelenmemiş (http) +2") }
        if (ipv4.matches(host)) { score += 2; reasons.add("Alan adı yerine IP adresi kullanılıyor +2") }
        if (host.contains("xn--")) { score += 2; reasons.add("Taklit karakterli (xn--) alan adı +2") }
        if (url.contains("@")) { score += 2; reasons.add("Adreste '@' işareti var +2") }
        val labels = if (host.isEmpty()) emptyList() else host.split(".")
        if (labels.size > 4) { score += 1; reasons.add("Çok fazla alt alan adı +1") }
        if (labels.isNotEmpty() && labels.last() in badTlds) { score += 1; reasons.add("Şüpheli uzantı (.${labels.last()}) +1") }
        if (url.length > 120) { score += 1; reasons.add("Adres çok uzun +1") }
        if (words.any { host.contains(it) } && host.contains("-")) {
            score += 1; reasons.add("Giriş/doğrulama kelimesi ve tire birlikte +1")
        }
        if (reasons.isEmpty()) reasons.add("Belirgin bir risk işareti bulunamadı.")
        return GuardResult(score, reasons)
    }
}

// ---------------------------------------------------------------- Depolama (JSON)
class Store(ctx: Context, private val key: String, private val max: Int) {
    private val prefs = ctx.getSharedPreferences("sbr", Context.MODE_PRIVATE)

    fun all(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val arr = JSONArray(prefs.getString(key, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Pair(o.optString("t"), o.optString("u")))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun save(list: List<Pair<String, String>>) {
        val arr = JSONArray()
        for (p in list.take(max)) arr.put(JSONObject().put("t", p.first).put("u", p.second))
        prefs.edit().putString(key, arr.toString()).apply()
    }

    fun contains(url: String) = all().any { it.second == url }

    /** En yeni en başta. */
    fun add(title: String, url: String) {
        val list = all().filter { it.second != url }.toMutableList()
        list.add(0, Pair(title, url))
        save(list)
    }

    fun remove(url: String) = save(all().filter { it.second != url })
    fun clear() = save(emptyList())
}

// ---------------------------------------------------------------- Aktivite
class MainActivity : Activity() {

    companion object {
        private var sRuntime: GeckoRuntime? = null
        private const val SEARCH = "https://duckduckgo.com/?q="

        private val START_HTML = """
            <!doctype html><html><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>S.BR</title>
            <style>
            body{margin:0;background:#0f1117;color:#e6e8ef;font-family:sans-serif;display:flex;
            flex-direction:column;align-items:center;justify-content:center;min-height:100vh}
            h1{font-size:64px;margin:0 0 24px;color:#6c8cff;letter-spacing:2px}
            form{width:min(90vw,560px);display:flex;gap:8px}
            input[type=text]{flex:1;padding:14px 18px;border-radius:28px;border:1px solid #2b3144;
            background:#232836;color:#e6e8ef;font-size:17px;outline:none}
            button{padding:0 22px;border:0;border-radius:28px;background:#6c8cff;color:#0f1117;font-weight:bold;font-size:16px}
            p{color:#8b90a0;margin-top:20px}
            </style></head><body>
            <h1>S.BR</h1>
            <form action="https://duckduckgo.com/" method="get">
            <input type="text" name="q" placeholder="DuckDuckGo'da ara" autocomplete="off">
            <button type="submit">Ara</button></form>
            <p>Hızlı, özel, Firefox motorlu tarayıcı</p>
            </body></html>
        """.trimIndent()

        val START_URI: String = "data:text/html;charset=utf-8," + Uri.encode(START_HTML)
    }

    private lateinit var runtime: GeckoRuntime
    private lateinit var geckoView: GeckoView
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var bookmarks: Store
    private lateinit var history: Store

    private val tabs = ArrayList<Tab>()
    private var current: Tab? = null
    private var nextId = 1
    private var vertical = false

    // UI
    private lateinit var btnBack: TextView
    private lateinit var btnFwd: TextView
    private lateinit var btnReload: TextView
    private lateinit var badge: TextView
    private lateinit var address: EditText
    private lateinit var btnStar: TextView
    private lateinit var progress: ProgressBar
    private lateinit var hScroll: HorizontalScrollView
    private lateinit var hTabs: LinearLayout
    private lateinit var sidePanel: LinearLayout
    private lateinit var vTabs: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------ yaşam döngüsü
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("sbr", MODE_PRIVATE)
        bookmarks = Store(this, "bookmarks", 500)
        history = Store(this, "history", 300)
        vertical = prefs.getBoolean("vertical_tabs", false)

        var rt = sRuntime
        if (rt == null) {
            val settings = GeckoRuntimeSettings.Builder().build()
            rt = GeckoRuntime.create(applicationContext, settings)
            // Sıkı izleme koruması
            rt.settings.contentBlocking
                .setAntiTracking(ContentBlocking.AntiTracking.STRICT)
                .setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
                .setStrictSocialTrackingProtection(true)
            sRuntime = rt
        }
        runtime = rt

        buildUi()
        applyLayoutMode()

        val data = intent?.data
        if (data != null) newTab(data.toString(), false) else newTab(START_URI, false)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val data = intent?.data
        if (data != null) newTab(data.toString(), false)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val t = current
        when {
            t != null && t.canBack -> t.session.goBack()
            tabs.size > 1 && t != null -> closeTab(t)
            else -> finish()
        }
    }

    // ------------------------------------------------------------ arayüz
    private fun roundBg(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun iconBtn(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(C_TEXT)
        textSize = 18f
        gravity = Gravity.CENTER
        minimumWidth = dp(40)
        minimumHeight = dp(40)
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
        }

        // Araç çubuğu
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(C_BAR)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        btnBack = iconBtn("◀") { current?.session?.goBack() }
        btnFwd = iconBtn("▶") { current?.session?.goForward() }
        btnReload = iconBtn("⟳") {
            val t = current
            if (t != null) { if (t.loading) t.session.stop() else t.session.reload() }
        }
        badge = iconBtn("🔒") { showGuardDialog() }
        address = EditText(this).apply {
            setTextColor(C_TEXT)
            setHintTextColor(C_DIM)
            hint = "Ara veya adres yaz"
            textSize = 15f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            background = roundBg(C_FIELD, 20)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnEditorActionListener { v, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_NULL) {
                    navigate(v.text.toString())
                    v.clearFocus()
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .hideSoftInputFromWindow(v.windowToken, 0)
                    true
                } else false
            }
            setOnFocusChangeListener { v, has -> if (has) (v as EditText).selectAll() }
        }
        btnStar = iconBtn("☆") { toggleBookmark() }
        val btnLayout = iconBtn("▤") { toggleLayout() }
        val btnMenu = iconBtn("⋮") { showMenu() }

        toolbar.addView(btnBack)
        toolbar.addView(btnFwd)
        toolbar.addView(btnReload)
        toolbar.addView(badge)
        toolbar.addView(address, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            setMargins(dp(4), 0, dp(4), 0)
        })
        toolbar.addView(btnStar)
        toolbar.addView(btnLayout)
        toolbar.addView(btnMenu)
        root.addView(toolbar, LinearLayout.LayoutParams(-1, -2))

        // İlerleme çubuğu
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = android.content.res.ColorStateList.valueOf(C_ACCENT)
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))

        // Yatay sekme çubuğu
        hScroll = HorizontalScrollView(this).apply {
            setBackgroundColor(C_BAR)
            isHorizontalScrollBarEnabled = false
        }
        hTabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        hScroll.addView(hTabs, FrameLayout.LayoutParams(-2, -2))
        root.addView(hScroll, LinearLayout.LayoutParams(-1, dp(44)))

        // İçerik: sol panel + GeckoView
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sidePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BAR)
        }
        val sideScroll = ScrollView(this)
        vTabs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        sideScroll.addView(vTabs, FrameLayout.LayoutParams(-1, -2))
        sidePanel.addView(sideScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val plus = TextView(this).apply {
            text = "+ Yeni sekme"
            setTextColor(C_BG)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = roundBg(C_ACCENT, 10)
            setOnClickListener { newTab(START_URI, false) }
        }
        sidePanel.addView(plus, LinearLayout.LayoutParams(-1, dp(44)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
        body.addView(sidePanel, LinearLayout.LayoutParams(dp(200), -1))

        geckoView = GeckoView(this)
        body.addView(geckoView, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun toggleLayout() {
        vertical = !vertical
        prefs.edit().putBoolean("vertical_tabs", vertical).apply()
        applyLayoutMode()
    }

    private fun applyLayoutMode() {
        hScroll.visibility = if (vertical) View.GONE else View.VISIBLE
        sidePanel.visibility = if (vertical) View.VISIBLE else View.GONE
        renderTabs()
    }

    private fun tabLabel(t: Tab): String {
        val base = if (t.title.isNotBlank()) t.title else if (t.url.startsWith("data:")) "S.BR" else t.url
        val s = if (base.length > 24) base.substring(0, 24) + "…" else base
        return if (t.isPrivate) "🕶 $s" else s
    }

    private fun renderTabs() {
        hTabs.removeAllViews()
        vTabs.removeAllViews()
        for (t in tabs.toList()) {
            val active = t === current
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundBg(if (active) C_FIELD else C_BAR, 10)
                if (active) setPadding(dp(10), 0, dp(2), 0) else setPadding(dp(10), 0, dp(2), 0)
            }
            val label = TextView(this).apply {
                text = tabLabel(t)
                setTextColor(if (active) C_ACCENT else C_TEXT)
                textSize = 13f
                setSingleLine(true)
                setOnClickListener { selectTab(t) }
            }
            val close = TextView(this).apply {
                text = "✕"
                setTextColor(C_DIM)
                gravity = Gravity.CENTER
                minimumWidth = dp(32)
                minimumHeight = dp(32)
                setOnClickListener { closeTab(t) }
            }
            row.addView(label, LinearLayout.LayoutParams(if (vertical) 0 else dp(140), -2, if (vertical) 1f else 0f))
            row.addView(close, LinearLayout.LayoutParams(dp(32), dp(32)))
            if (vertical) {
                vTabs.addView(row, LinearLayout.LayoutParams(-1, dp(40)).apply { setMargins(0, 0, 0, dp(4)) })
            } else {
                hTabs.addView(row, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
            }
        }
        if (!vertical) {
            val plus = iconBtn("+") { newTab(START_URI, false) }
            plus.setTextColor(C_ACCENT)
            hTabs.addView(plus, LinearLayout.LayoutParams(dp(40), dp(40)))
        }
    }

    // ------------------------------------------------------------ sekmeler
    private fun newTab(url: String, priv: Boolean, select: Boolean = true): Tab {
        val builder = GeckoSessionSettings.Builder()
        if (priv) builder.usePrivateMode(true)
        val session = GeckoSession(builder.build())
        val tab = Tab(nextId++, session, "", url, isPrivate = priv)
        attachDelegates(tab)
        tabs.add(tab)
        if (select) selectTab(tab)
        session.loadUri(url)
        renderTabs()
        return tab
    }

    private fun selectTab(tab: Tab) {
        if (!tab.session.isOpen) tab.session.open(runtime)
        if (geckoView.session != null) geckoView.releaseSession()
        geckoView.setSession(tab.session)
        current = tab
        updateToolbar()
        renderTabs()
    }

    private fun closeTab(tab: Tab) {
        val idx = tabs.indexOf(tab)
        if (idx < 0) return
        if (tabs.size == 1) {
            // Son sekme: sıfırla (başlangıç sayfası)
            tab.session.loadUri(START_URI)
            return
        }
        tabs.removeAt(idx)
        if (current === tab) {
            geckoView.releaseSession()
            current = null
            selectTab(tabs[minOf(idx, tabs.size - 1)])
        }
        tab.session.close()
        renderTabs()
    }

    private fun tabFor(session: GeckoSession): Tab? = tabs.firstOrNull { it.session === session }

    private fun attachDelegates(tab: Tab) {
        val s = tab.session

        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                val t = tabFor(session) ?: return
                t.url = url ?: ""
                if (t === current) updateToolbar()
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                val t = tabFor(session) ?: return
                t.canBack = canGoBack
                if (t === current) updateToolbar()
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                val t = tabFor(session) ?: return
                t.canFwd = canGoForward
                if (t === current) updateToolbar()
            }

            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                val builder = GeckoSessionSettings.Builder()
                if (tabFor(session)?.isPrivate == true) builder.usePrivateMode(true)
                val ns = GeckoSession(builder.build())
                val nt = Tab(nextId++, ns, "", uri, isPrivate = tabFor(session)?.isPrivate == true)
                attachDelegates(nt)
                tabs.add(nt)
                // GeckoView sessiyonu kendisi açar; seçimi sonraya bırakıyoruz.
                geckoView.post { selectTab(nt) }
                return GeckoResult.fromValue(ns)
            }
        }

        s.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                val t = tabFor(session) ?: return
                t.title = title ?: ""
                val u = t.url
                if (u.startsWith("http") && !t.isPrivate) {
                    history.add(if (t.title.isBlank()) u else t.title, u)
                }
                renderTabs()
            }

            override fun onCloseRequest(session: GeckoSession) {
                val t = tabFor(session) ?: return
                closeTab(t)
            }

            override fun onCrash(session: GeckoSession) {
                val t = tabFor(session) ?: return
                Toast.makeText(this@MainActivity, "Sekme çöktü, yeniden yükleniyor", Toast.LENGTH_SHORT).show()
                if (!session.isOpen) session.open(runtime)
                session.loadUri(if (t.url.isEmpty()) START_URI else t.url)
            }
        }

        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                val t = tabFor(session) ?: return
                t.loading = true
                if (t === current) updateToolbar()
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                val t = tabFor(session) ?: return
                t.loading = false
                if (t === current) {
                    progress.visibility = View.GONE
                    updateToolbar()
                }
            }

            override fun onProgressChange(session: GeckoSession, progressValue: Int) {
                val t = tabFor(session) ?: return
                if (t === current) {
                    progress.progress = progressValue
                    progress.visibility = if (progressValue in 1..99) View.VISIBLE else View.GONE
                }
            }
        }
        // İzin delegesi: GeckoView varsayılanları kullanılır (çökme yok).
    }

    // ------------------------------------------------------------ gezinme
    private fun looksLikeUrl(s: String): Boolean {
        if (s.contains(" ")) return false
        if (s.contains("://") || s.startsWith("about:") || s.startsWith("data:")) return true
        if (s.startsWith("localhost")) return true
        val host = s.substringBefore('/').substringBefore('?').substringBefore(':')
        return host.contains(".") && !host.endsWith(".") && !host.startsWith(".")
    }

    private fun navigate(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        val target = when {
            text.contains("://") || text.startsWith("about:") || text.startsWith("data:") -> text
            looksLikeUrl(text) -> "https://$text"
            else -> SEARCH + Uri.encode(text)
        }
        current?.let {
            it.url = target
            it.session.loadUri(target)
        }
    }

    private fun updateToolbar() {
        val t = current ?: return
        btnBack.alpha = if (t.canBack) 1f else 0.35f
        btnFwd.alpha = if (t.canFwd) 1f else 0.35f
        btnReload.text = if (t.loading) "✕" else "⟳"
        if (!address.hasFocus()) {
            address.setText(if (t.url.startsWith("data:") || t.url == "about:blank") "" else t.url)
        }
        val g = Guard.check(t.url)
        badge.text = g.icon
        btnStar.text = if (t.url.startsWith("http") && bookmarks.contains(t.url)) "★" else "☆"
        btnStar.setTextColor(if (btnStar.text == "★") C_ACCENT else C_TEXT)
    }

    // ------------------------------------------------------------ menü & diyaloglar
    private fun showMenu() {
        val items = arrayOf(
            "Yeni sekme",
            "Gizli sekme",
            if (vertical) "Yatay sekmelere geç" else "Dikey sekmelere geç",
            "Yer imleri",
            "Geçmiş",
            "S.BR Guard raporu"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> newTab(START_URI, false)
                    1 -> newTab(START_URI, true)
                    2 -> toggleLayout()
                    3 -> showList("Yer imleri", bookmarks, true)
                    4 -> showList("Geçmiş", history, false)
                    5 -> showGuardDialog()
                }
            }
            .show()
    }

    private fun showList(title: String, store: Store, isBookmarks: Boolean) {
        val list = store.all()
        if (list.isEmpty()) {
            AlertDialog.Builder(this).setTitle(title).setMessage("Henüz bir şey yok.")
                .setPositiveButton("Tamam", null).show()
            return
        }
        val labels = list.map { (t, u) -> (if (t.isBlank()) u else t) + "\n" + u }.toTypedArray()
        val b = AlertDialog.Builder(this).setTitle(title)
            .setItems(labels) { _, i ->
                current?.session?.loadUri(list[i].second)
            }
            .setNegativeButton("Kapat", null)
        if (isBookmarks) {
            b.setNeutralButton("Sil...") { _, _ -> showDeleteList(title, store, list) }
        } else {
            b.setNeutralButton("Temizle") { _, _ -> store.clear() }
        }
        b.show()
    }

    private fun showDeleteList(title: String, store: Store, list: List<Pair<String, String>>) {
        val labels = list.map { if (it.first.isBlank()) it.second else it.first }.toTypedArray()
        AlertDialog.Builder(this).setTitle("$title - silmek için dokun")
            .setItems(labels) { _, i ->
                store.remove(list[i].second)
                updateToolbar()
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun toggleBookmark() {
        val t = current ?: return
        if (!t.url.startsWith("http")) {
            Toast.makeText(this, "Bu sayfa eklenemez", Toast.LENGTH_SHORT).show()
            return
        }
        if (bookmarks.contains(t.url)) {
            bookmarks.remove(t.url)
            Toast.makeText(this, "Yer imi silindi", Toast.LENGTH_SHORT).show()
        } else {
            bookmarks.add(if (t.title.isBlank()) t.url else t.title, t.url)
            Toast.makeText(this, "Yer imi eklendi", Toast.LENGTH_SHORT).show()
        }
        updateToolbar()
    }

    private fun showGuardDialog() {
        val t = current ?: return
        val g = Guard.check(t.url)
        val msg = StringBuilder()
        msg.append("Puan: ${g.score}\n\n")
        for (r in g.reasons) msg.append("• ").append(r).append("\n")
        msg.append("\nNot: S.BR Guard yalnızca adresi (URL) kontrol eder; sayfanın içeriğini taramaz.")
        AlertDialog.Builder(this)
            .setTitle("${g.icon} ${g.label}")
            .setMessage(msg.toString())
            .setPositiveButton("Tamam", null)
            .show()
    }

    override fun onDestroy() {
        // Runtime uygulama boyunca paylaşılır; oturumlar kapatılır.
        if (isFinishing) {
            geckoView.releaseSession()
            for (t in tabs) t.session.close()
            tabs.clear()
        }
        super.onDestroy()
    }
}
