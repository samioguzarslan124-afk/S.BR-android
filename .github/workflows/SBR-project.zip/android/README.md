# S.BR - Tarayıcı

GeckoView (Firefox motoru) tabanlı Android tarayıcı. Kullanılan sürüm: `org.mozilla.geckoview:geckoview:158.0.20261021001945`
(Mozilla Maven: https://maven.mozilla.org/maven2/).

Özellikler: yatay/dikey sekme düzeni, gizli sekme, yer imleri, geçmiş, S.BR Guard adres kontrolü, sıkı izleme koruması.

## APK nasıl alınır (telefon/tabletten)
1. GitHub'da yeni bir depo (repository) oluştur.
2. Bu klasördeki tüm dosyaları (`.github` klasörü dahil) depoya yükle ("Add file > Upload files").
3. Depoda **Actions** sekmesini aç, "Build APK" çalışmasının bitmesini bekle (birkaç dakika).
4. Çalışmaya tıkla, en altta **Artifacts** bölümünden `S.BR-apk` dosyasını indir ve zip'ten çıkar.
5. APK'ya dokunup kur ("bilinmeyen kaynaklara izin ver" gerekebilir).
