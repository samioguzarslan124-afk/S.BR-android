# S.BR – Windows

Electron tabanlı masaüstü tarayıcı (Chromium motoru).

## Yerel çalıştırma (Node.js 20+ kurulu olmalı)

```
npm install
npm start
```

## EXE üretme

```
npm run dist
```
Çıktı `dist/` klasörüne düşer (NSIS kurulum + taşınabilir sürüm).

## GitHub Actions ile

1. Bu klasörü bir GitHub deposuna yükle.
2. Actions sekmesinde "Build Windows EXE" çalışır.
3. Bittiğinde çalıştırmanın sonundan `S.BR-exe` dosyasını indir.

## Özellikler

- Yatay / dikey sekme geçişi (menü > "Yatay / dikey sekme")
- Gizli sekme, yer imleri, geçmiş
- S.BR Guard: adres çubuğundaki rozet ve menüden ulaşılan rapor (yalnızca adrese bakar)
- Kısayollar: Ctrl+T, Ctrl+W, Ctrl+L, Ctrl+R, Ctrl+Tab, Alt+← / Alt+→
