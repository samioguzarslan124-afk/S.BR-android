const { contextBridge, ipcRenderer } = require('electron');

// Arayüz sayfaları yalnızca bu kanalları kullanabilir
const SEND = [
  'ui:ready', 'tab:new', 'tab:private', 'tab:switch', 'tab:close',
  'nav:go', 'nav:back', 'nav:forward', 'nav:reload',
  'layout:toggle', 'bm:toggle', 'bm:clear', 'hist:clear',
  'ui:expand', 'ui:collapse'
];
const RECV = ['state', 'focus-address'];

contextBridge.exposeInMainWorld('sbr', {
  send: (channel, ...args) => {
    if (SEND.includes(channel)) ipcRenderer.send(channel, ...args);
  },
  on: (channel, fn) => {
    if (RECV.includes(channel)) ipcRenderer.on(channel, (_e, ...a) => fn(...a));
  }
});
