const { app, BaseWindow, WebContentsView, ipcMain, session } = require('electron');
const fs = require('fs');
const path = require('path');

const CHROME_H = 88;   // yatay mod: sekme şeridi (40) + araç çubuğu (48)
const CHROME_V = 48;   // dikey mod: yalnızca araç çubuğu
const SIDE_W = 220;    // dikey mod: sol sekme paneli genişliği
const DDG = 'https://duckduckgo.com/?q=';

const START_HTML = `<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>S.BR</title>
<style>
body{margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:24px;background:#0f1117;color:#e8eaf2;font-family:system-ui,sans-serif}
h1{font-size:56px;margin:0}h1 span{color:#6c8cff}
form{display:flex;width:min(560px,90%)}
input{flex:1;padding:14px 18px;border-radius:28px 0 0 28px;border:1px solid #2b3042;background:#171a23;color:#e8eaf2;font-size:16px;outline:0}
button{padding:0 22px;border:0;border-radius:0 28px 28px 0;background:#6c8cff;color:#fff;font-size:16px}
</style></head>
<body><h1>S<span>.</span>BR</h1>
<form action="https://duckduckgo.com/" method="get"><input name="q" placeholder="S.BR ile ara veya adres yaz" autofocus><button>Ara</button></form>
</body></html>`;
const START_URL = 'data:text/html;charset=utf-8,' + encodeURIComponent(START_HTML);

let cfg, bookmarks, history;
let win = null, chromeView = null, sideView = null;
let tabs = [], activeId = null, nextId = 1, expanded = false;
const attached = new Set();

/* ---------- Kalıcı veri ---------- */
const dataFile = n => path.join(app.getPath('userData'), n);
function readJSON(n, fb) { try { return JSON.parse(fs.readFileSync(dataFile(n), 'utf8')); } catch { return fb; } }
function writeJSON(n, v) { try { fs.writeFileSync(dataFile(n), JSON.stringify(v, null, 2)); } catch (e) { console.error(e); } }

/* ---------- Yardımcılar ---------- */
const isVertical = () => cfg.layout === 'vertical';
const active = () => tabs.find(t => t.id === activeId);
// Kullanıcı gezintisine izin verilen şemalar (data: ve file: engelli)
const allowed = u => { try { return ['http:', 'https:', 'about:'].includes(new URL(u).protocol); } catch { return false; } };

function normalize(input) {
  const s = (input || '').trim();
  if (!s) return START_URL;
  if (/^https?:\/\//i.test(s)) return s;
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/.test(s)) return 'https://' + s;
  return DDG + encodeURIComponent(s);
}

function snapshot() {
  return {
    layout: cfg.layout,
    activeId,
    tabs: tabs.map(t => ({ id: t.id, title: t.title, url: t.url, isPrivate: t.isPrivate, canBack: t.canBack, canFwd: t.canFwd, loading: t.loading })),
    bookmarks,
    history: history.slice(-100).reverse()
  };
}

function broadcast() {
  const s = snapshot();
  for (const v of [chromeView, sideView]) {
    if (v && !v.webContents.isDestroyed()) v.webContents.send('state', s);
  }
}

/* ---------- Yerleşim ---------- */
function setAttached(view, on) {
  if (on && !attached.has(view)) { win.contentView.addChildView(view); attached.add(view); }
  if (!on && attached.has(view)) { win.contentView.removeChildView(view); attached.delete(view); }
}

// Aktif sekmeyi göster; panel açıkken (expanded) sayfayı gizle ki menü üstte görünsün
function layout() {
  if (!win || win.isDestroyed()) return;
  const [W, H] = win.getContentSize();
  const vertical = isVertical();

  chromeView.setBounds({ x: 0, y: 0, width: W, height: expanded ? H : (vertical ? CHROME_V : CHROME_H) });

  const sideOn = vertical && !expanded;
  setAttached(sideView, sideOn);
  sideView.setBounds(sideOn
    ? { x: 0, y: CHROME_V, width: SIDE_W, height: Math.max(0, H - CHROME_V) }
    : { x: 0, y: 0, width: 0, height: 0 });

  const cur = active();
  for (const t of tabs) setAttached(t.view, !expanded && t === cur);

  if (cur && !expanded) {
    const x = sideOn ? SIDE_W : 0;
    const y = vertical ? CHROME_V : CHROME_H;
    cur.view.setBounds({ x, y, width: Math.max(0, W - x), height: Math.max(0, H - y) });
  }
}

function setExpanded(v) { expanded = v; layout(); broadcast(); }

/* ---------- Sekmeler ---------- */
function addHistory(url, title) {
  history.push({ url, title, t: Date.now() });
  history = history.slice(-300);
  writeJSON('history.json', history);
}

function createTab(url = START_URL, isPrivate = false) {
  const view = new WebContentsView({
    webPreferences: {
      partition: isPrivate ? 'sbr-private' : 'persist:sbr', // özel sekme: diskte veri yok
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  const tab = { id: nextId++, view, title: 'Yeni sekme', url: '', isPrivate, canBack: false, canFwd: false, loading: false, lastRecorded: '' };
  tabs.push(tab);
  const wc = view.webContents;
  const sync = () => { tab.canBack = wc.canGoBack(); tab.canFwd = wc.canGoForward(); };

  wc.on('page-title-updated', (e, title) => { tab.title = title; broadcast(); });
  wc.on('did-navigate', (e, u) => { tab.url = u; sync(); broadcast(); });
  wc.on('did-navigate-in-page', (e, u) => { tab.url = u; sync(); broadcast(); });
  wc.on('did-start-loading', () => { tab.loading = true; broadcast(); });
  wc.on('did-stop-loading', () => {
    tab.loading = false; sync();
    if (!tab.isPrivate && tab.url.startsWith('http') && tab.lastRecorded !== tab.url) {
      tab.lastRecorded = tab.url;
      addHistory(tab.url, tab.title);
    }
    broadcast();
  });
  wc.on('will-navigate', (e, u) => { if (!allowed(u)) e.preventDefault(); });
  wc.on('will-redirect', (e, u) => { if (!allowed(u)) e.preventDefault(); });
  wc.setWindowOpenHandler(({ url: u }) => {
    if (allowed(u)) createTab(u, isPrivate); // target=_blank ve popup'lar yeni sekme olur
    return { action: 'deny' };
  });
  wc.on('before-input-event', (e, input) => { if (handleKey(input, tab.id)) e.preventDefault(); });
  wc.on('render-process-gone', () => wc.reload());
  wc.loadURL(url).catch(() => {});

  switchTo(tab.id);
  return tab;
}

function switchTo(id) {
  if (!tabs.some(t => t.id === id)) return;
  activeId = id;
  layout();
  broadcast();
  active()?.view.webContents.focus();
}

function closeTab(id) {
  const i = tabs.findIndex(t => t.id === id);
  if (i < 0) return;
  const [tab] = tabs.splice(i, 1);
  setAttached(tab.view, false);
  if (!tabs.length) {
    createTab(START_URL); // son sekme kapanırsa uygulamayı kapatmak yerine başlangıç sayfası
  } else if (activeId === id) {
    activeId = tabs[Math.max(0, i - 1)].id;
  }
  try { tab.view.webContents.close(); } catch {}
  layout();
  broadcast();
}

function cycle(d) {
  if (tabs.length < 2) return;
  const i = tabs.findIndex(t => t.id === activeId);
  switchTo(tabs[(i + d + tabs.length) % tabs.length].id);
}

function back() { const wc = active()?.view.webContents; if (wc && wc.canGoBack()) wc.goBack(); }
function forward() { const wc = active()?.view.webContents; if (wc && wc.canGoForward()) wc.goForward(); }

function navigateActive(input) {
  const t = active();
  if (t) t.view.webContents.loadURL(normalize(input)).catch(() => {});
}

function toggleBookmark() {
  const t = active();
  if (!t || !t.url.startsWith('http')) return;
  const i = bookmarks.findIndex(b => b.url === t.url);
  if (i >= 0) bookmarks.splice(i, 1);
  else bookmarks.push({ url: t.url, title: t.title });
  writeJSON('bookmarks.json', bookmarks);
  broadcast();
}

function toggleLayout() {
  cfg.layout = isVertical() ? 'horizontal' : 'vertical';
  writeJSON('settings.json', cfg);
  layout();
  broadcast();
}

/* ---------- Klavye kısayolları (sayfa ve arayüz için ortak) ---------- */
function handleKey(input, tabId) {
  if (input.type !== 'keyDown') return false;
  const ctrl = input.control || input.meta;
  const k = input.key;
  const lk = k.toLowerCase();
  if (ctrl && lk === 't') { createTab(START_URL); return true; }
  if (ctrl && lk === 'w') { closeTab(tabId ?? activeId); return true; }
  if (ctrl && lk === 'l') {
    chromeView.webContents.focus();
    chromeView.webContents.send('focus-address');
    return true;
  }
  if (ctrl && lk === 'r') { active()?.view.webContents.reload(); return true; }
  if (ctrl && k === 'Tab') { cycle(input.shift ? -1 : 1); return true; }
  if (input.alt && k === 'ArrowLeft') { back(); return true; }
  if (input.alt && k === 'ArrowRight') { forward(); return true; }
  return false;
}

/* ---------- IPC (yalnızca kendi arayüzümüzden) ---------- */
function wireIpc() {
  ipcMain.on('ui:ready', e => e.sender.send('state', snapshot()));
  ipcMain.on('tab:new', () => createTab(START_URL));
  ipcMain.on('tab:private', () => createTab(START_URL, true));
  ipcMain.on('tab:switch', (_e, id) => switchTo(Number(id)));
  ipcMain.on('tab:close', (_e, id) => closeTab(Number(id)));
  ipcMain.on('nav:go', (_e, s) => navigateActive(String(s ?? '')));
  ipcMain.on('nav:back', () => back());
  ipcMain.on('nav:forward', () => forward());
  ipcMain.on('nav:reload', () => active()?.view.webContents.reload());
  ipcMain.on('layout:toggle', () => toggleLayout());
  ipcMain.on('bm:toggle', () => toggleBookmark());
  ipcMain.on('bm:clear', () => { bookmarks = []; writeJSON('bookmarks.json', bookmarks); broadcast(); });
  ipcMain.on('hist:clear', () => { history = []; writeJSON('history.json', history); broadcast(); });
  ipcMain.on('ui:expand', () => setExpanded(true));
  ipcMain.on('ui:collapse', () => setExpanded(false));
}

/* ---------- Pencere ---------- */
function createWindow() {
  win = new BaseWindow({
    width: 1280, height: 800, minWidth: 600, minHeight: 400,
    title: 'S.BR', backgroundColor: '#0f1117'
  });

  const webPrefs = {
    preload: path.join(__dirname, 'preload.js'),
    contextIsolation: true,
    nodeIntegration: false,
    sandbox: true
  };
  chromeView = new WebContentsView({ webPreferences: webPrefs });
  sideView = new WebContentsView({ webPreferences: webPrefs });
  chromeView.webContents.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  sideView.webContents.loadFile(path.join(__dirname, 'renderer', 'sidebar.html'));
  chromeView.webContents.on('before-input-event', (e, input) => { if (handleKey(input)) e.preventDefault(); });

  setAttached(chromeView, true);
  win.on('resize', layout);
  win.on('closed', () => { win = null; });

  layout();
  createTab(START_URL);
}

function hardenSessions() {
  // Konum, bildirim, kamera vb. izinleri her zaman reddet
  for (const p of ['persist:sbr', 'sbr-private']) {
    session.fromPartition(p).setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  }
}

app.whenReady().then(() => {
  cfg = readJSON('settings.json', { layout: 'horizontal' });
  bookmarks = readJSON('bookmarks.json', []);
  history = readJSON('history.json', []);
  hardenSessions();
  wireIpc();
  createWindow();
});

app.on('window-all-closed', () => app.quit());
